"""
Merkezi ayar dosyası. .env dosyasından değerleri okur.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

# ---- API anahtarları ----
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

# ---- Seslendirme ----
TTS_VOICE = os.getenv("TTS_VOICE", "tr-TR-AhmetNeural")

# ---- Görsel üretim ----
IMAGE_PROVIDER = os.getenv("IMAGE_PROVIDER", "pollinations")

# ---- YouTube ----
YOUTUBE_CLIENT_SECRETS_FILE = os.getenv(
    "YOUTUBE_CLIENT_SECRETS_FILE", "config/youtube_client_secret.json"
)

# ---- Klasörler ----
OUTPUT_DIR = BASE_DIR / "output"
SCRIPTS_DIR = OUTPUT_DIR / "scripts"
AUDIO_DIR = OUTPUT_DIR / "audio"
IMAGES_DIR = OUTPUT_DIR / "images"
SUBTITLES_DIR = OUTPUT_DIR / "subtitles"
VIDEOS_DIR = OUTPUT_DIR / "videos"
ASSETS_DIR = BASE_DIR / "assets"
FONTS_DIR = ASSETS_DIR / "fonts"
MUSIC_DIR = ASSETS_DIR / "music"

for _d in (SCRIPTS_DIR, AUDIO_DIR, IMAGES_DIR, SUBTITLES_DIR, VIDEOS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# ---- İçerik nişi (varsayılan; main.py --niche ile değiştirilebilir) ----
DEFAULT_NICHE = "spor, sağlık ve beslenme"

# ---- Video ayarları ----
LONGFORM_TARGET_MINUTES = 11  # 10-12 dk hedefi
LONGFORM_RESOLUTION = (1920, 1080)  # 16:9
SHORTS_RESOLUTION = (1080, 1920)  # 9:16
FPS = 30

# Türkçe ortalama konuşma hızı ~ 140-155 kelime/dk (edge-tts normal hızda)
WORDS_PER_MINUTE = 145
