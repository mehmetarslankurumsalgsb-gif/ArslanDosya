"""
YouTube'a otomatik yükleme modülü (YouTube Data API v3).

Kurulum (bir kereye mahsus):
  1) https://console.cloud.google.com adresinde bir proje oluştur.
  2) "YouTube Data API v3"ü etkinleştir.
  3) "OAuth client ID" (Desktop app tipi) oluştur, JSON'ı indir.
  4) İndirdiğin dosyayı config/youtube_client_secret.json olarak kaydet.
  5) İlk çalıştırmada tarayıcı açılacak, Google hesabınla giriş yapıp izin
     vereceksin. Sonraki çalıştırmalarda config/youtube_token.json
     otomatik kullanılacağı için tekrar giriş istemez.

Not: Instagram Reels / TikTok / Facebook için resmi API'ler ya çok kısıtlı
ya da onay süreci gerektiriyor. Bu yüzden ilk aşamada bu modül sadece
YouTube'u otomatikleştiriyor; diğer platformlar için pipeline, videoyu
hazırlayıp "şuraya sürükle-bırak yükle" diyen bir kontrol listesi üretir
(bkz. main.py). İstersen ileride Meta Graph API (Instagram/Facebook) ve
TikTok Content Posting API entegrasyonunu da ekleyebiliriz.
"""
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
from config import settings

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
TOKEN_PATH = Path(settings.YOUTUBE_CLIENT_SECRETS_FILE).parent / "youtube_token.json"


def _get_authenticated_service():
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build

    creds = None
    if TOKEN_PATH.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_PATH), SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            secrets_path = Path(settings.YOUTUBE_CLIENT_SECRETS_FILE)
            if not secrets_path.exists():
                raise FileNotFoundError(
                    f"{secrets_path} bulunamadı. Modülün docstring'indeki "
                    "kurulum adımlarını izleyin."
                )
            flow = InstalledAppFlow.from_client_secrets_file(str(secrets_path), SCOPES)
            creds = flow.run_local_server(port=0)
        TOKEN_PATH.write_text(creds.to_json(), encoding="utf-8")

    return build("youtube", "v3", credentials=creds)


def upload_video(
    video_path: str,
    title: str,
    description: str,
    tags: list[str],
    category_id: str = "26",  # 26 = Howto & Style; spor/sağlık için 17 (Sports) de uygun
    privacy_status: str = "private",  # onay sürecin bitene kadar "private" öneriyoruz
    is_shorts: bool = False,
) -> str:
    """Videoyu YouTube'a yükler, video ID döner."""
    from googleapiclient.http import MediaFileUpload

    youtube = _get_authenticated_service()

    final_title = title
    final_description = description
    if is_shorts and "#shorts" not in final_title.lower():
        final_title = f"{final_title} #Shorts"
        final_description = f"{final_description}\n\n#Shorts"

    body = {
        "snippet": {
            "title": final_title[:100],
            "description": final_description,
            "tags": tags,
            "categoryId": category_id,
        },
        "status": {
            "privacyStatus": privacy_status,
            "selfDeclaredMadeForKids": False,
        },
    }

    media = MediaFileUpload(video_path, chunksize=-1, resumable=True, mimetype="video/mp4")
    request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)

    print(f"[publisher_youtube] Yükleme başlıyor: {video_path}")
    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"[publisher_youtube] Yükleniyor... %{int(status.progress() * 100)}")

    video_id = response["id"]
    print(f"[publisher_youtube] Yükleme tamamlandı: https://youtu.be/{video_id}")
    return video_id


def print_manual_upload_checklist(script: dict, video_paths: dict):
    """
    Instagram/TikTok/Facebook otomasyonu henüz kurulmadığı için, kullanıcının
    hazır videoyu hızlıca elle paylaşabilmesi için bir kontrol listesi basar.
    """
    print("\n" + "=" * 60)
    print("DİĞER PLATFORMLAR İÇİN PAYLAŞIM KONTROL LİSTESİ")
    print("=" * 60)
    print(f"Başlık: {script['title']}")
    print(f"Caption (IG/TikTok): {script['shorts_script']['caption']}")
    print(f"Hashtagler: {' '.join(script.get('hashtags', []))}")
    print("\nYüklenecek dosyalar:")
    for label, path in video_paths.items():
        print(f"  - {label}: {path}")
    print(
        "\nInstagram Reels / TikTok / Facebook: şu an için bu dosyaları "
        "ilgili uygulamadan elle yükleyin. İstersen ileride bunu da "
        "Meta Graph API / TikTok Content Posting API ile otomatikleştirebiliriz."
    )
    print("=" * 60 + "\n")
