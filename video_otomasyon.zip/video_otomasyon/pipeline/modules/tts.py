"""
Seslendirme modülü — ücretsiz, API key gerektirmeyen edge-tts (Microsoft Edge
tarayıcısının seslendirme motoru) kullanır.

Bonus: edge-tts, konuşma sırasında her kelimenin ses dosyasındaki tam zamanını
("word boundary") döndürür. Bunu kaydederek subtitles.py modülünde otomatik,
kelime-hizalı alt yazı (SRT) üretebiliyoruz — ayrı bir "speech-to-text" adımına
gerek kalmıyor.
"""
import asyncio
import json
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
from config import settings

try:
    import edge_tts
except ImportError:
    edge_tts = None


async def _synthesize_async(text: str, out_audio_path: Path, voice: str):
    if edge_tts is None:
        raise RuntimeError(
            "edge-tts kurulu değil. `pip install edge-tts` çalıştırın "
            "(requirements.txt içinde mevcut)."
        )

    communicate = edge_tts.Communicate(text, voice)
    word_boundaries = []

    with open(out_audio_path, "wb") as audio_file:
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                audio_file.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                word_boundaries.append(
                    {
                        # edge-tts zamanları 100 nanosaniye biriminde verir -> saniyeye çevir
                        "start": chunk["offset"] / 10_000_000,
                        "duration": chunk["duration"] / 10_000_000,
                        "text": chunk["text"],
                    }
                )
    return word_boundaries


def synthesize(text: str, out_name: str, voice: str = None) -> dict:
    """
    text -> mp3 (output/audio/<out_name>.mp3) + kelime zamanlamaları
    (output/audio/<out_name>_words.json)

    Dönüş: {"audio_path": ..., "words_path": ..., "duration": float}
    """
    voice = voice or settings.TTS_VOICE
    out_audio_path = settings.AUDIO_DIR / f"{out_name}.mp3"
    out_words_path = settings.AUDIO_DIR / f"{out_name}_words.json"

    word_boundaries = asyncio.run(_synthesize_async(text, out_audio_path, voice))

    out_words_path.write_text(
        json.dumps(word_boundaries, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    duration = 0.0
    if word_boundaries:
        last = word_boundaries[-1]
        duration = last["start"] + last["duration"]

    print(
        f"[tts] Seslendirme oluşturuldu: {out_audio_path} "
        f"(~{duration:.1f} sn, ses: {voice})"
    )
    return {
        "audio_path": str(out_audio_path),
        "words_path": str(out_words_path),
        "duration": duration,
    }


async def list_turkish_voices():
    """Kullanılabilir Türkçe sesleri listeler (voice seçimi için yardımcı)."""
    if edge_tts is None:
        print("edge-tts kurulu değil.")
        return
    voices = await edge_tts.list_voices()
    for v in voices:
        if v["Locale"].startswith("tr-"):
            print(f"{v['ShortName']:25s} {v['Gender']}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--list-voices":
        asyncio.run(list_turkish_voices())
    else:
        sample = "Merhaba, bu edge-tts ile oluşturulan bir test seslendirmesidir."
        synthesize(sample, "test")
