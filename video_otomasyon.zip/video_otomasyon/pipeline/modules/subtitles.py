"""
Alt yazı modülü — tts.py'nin ürettiği kelime-zamanlama verisinden (word
boundaries) otomatik, tam senkronize SRT dosyası oluşturur.

Ayrı bir konuşma-tanıma (speech-to-text) adımına ihtiyaç yok çünkü edge-tts
zaten her kelimenin ses dosyasındaki tam zamanını veriyor — bu hem daha
hızlı hem %100 doğru (transkripsiyon hatası riski yok).
"""
import json
import sys
from datetime import timedelta
from pathlib import Path

import srt

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
from config import settings

MAX_CHARS_PER_CAPTION = 42  # kısa video alt yazı okunabilirliği için standart
MAX_WORDS_PER_CAPTION = 7


def _group_words(words: list[dict]) -> list[dict]:
    """Kelimeleri kısa, okunabilir alt yazı bloklarına grupla."""
    groups = []
    current = []
    current_len = 0

    for w in words:
        text = w["text"]
        would_be_len = current_len + len(text) + 1
        if current and (
            len(current) >= MAX_WORDS_PER_CAPTION or would_be_len > MAX_CHARS_PER_CAPTION
        ):
            groups.append(current)
            current = []
            current_len = 0
        current.append(w)
        current_len += len(text) + 1

    if current:
        groups.append(current)
    return groups


def words_to_srt(words: list[dict], out_path: Path) -> Path:
    groups = _group_words(words)
    subtitles = []
    for i, group in enumerate(groups, start=1):
        start = group[0]["start"]
        end = group[-1]["start"] + group[-1]["duration"]
        text = " ".join(w["text"] for w in group)
        subtitles.append(
            srt.Subtitle(
                index=i,
                start=timedelta(seconds=start),
                end=timedelta(seconds=end),
                content=text,
            )
        )
    out_path.write_text(srt.compose(subtitles), encoding="utf-8")
    return out_path


def generate_subtitles(words_json_path: str, out_name: str) -> str:
    """
    tts.synthesize()'ın döndürdüğü words_path -> output/subtitles/<out_name>.srt
    """
    words = json.loads(Path(words_json_path).read_text(encoding="utf-8"))
    out_path = settings.SUBTITLES_DIR / f"{out_name}.srt"
    words_to_srt(words, out_path)
    print(f"[subtitles] Alt yazı oluşturuldu: {out_path} ({len(words)} kelime)")
    return str(out_path)


if __name__ == "__main__":
    # Test: önce tts.py çalıştırılıp test_words.json üretilmiş olmalı
    test_words_path = settings.AUDIO_DIR / "test_words.json"
    if test_words_path.exists():
        generate_subtitles(str(test_words_path), "test")
    else:
        print("Önce `python pipeline/modules/tts.py` çalıştırıp test sesi üretin.")
