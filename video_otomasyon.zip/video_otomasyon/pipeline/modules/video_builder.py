"""
Video birleştirme modülü.

Akış:
  1) Görselleri (Ken Burns / yavaş zoom efektiyle) + seslendirmeyi moviepy ile
     birleştirip "ham" bir video oluşturur (alt yazısız).
  2) Alt yazıyı ffmpeg'in `subtitles` filtresiyle videoya "yakar" (hard-sub) —
     böylece TikTok/Instagram/YouTube'a nasıl yüklenirse yüklensin alt yazı
     her zaman görünür, ayrı bir .srt yüklemeye gerek kalmaz.

Neden ffmpeg ile hard-sub? moviepy'nin TextClip'i ImageMagick gerektiriyor ve
kurulumu can sıkıcı olabiliyor; ffmpeg + libass (imageio-ffmpeg ile birlikte
gelir) çok daha güvenilir ve hızlı çalışıyor.
"""
import subprocess
import sys
from pathlib import Path

import imageio_ffmpeg
from moviepy.editor import (
    AudioFileClip,
    CompositeVideoClip,
    ImageClip,
    concatenate_videoclips,
)

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
from config import settings

FFMPEG_EXE = imageio_ffmpeg.get_ffmpeg_exe()


def _ken_burns_clip(image_path: str, duration: float, resolution: tuple[int, int]):
    """Statik görseli yavaşça yakınlaştıran (Ken Burns) bir klip üretir."""
    w, h = resolution
    clip = ImageClip(image_path)

    # Görseli hedef çözünürlüğü kaplayacak şekilde ölçekle (crop-to-fill)
    clip = clip.resize(height=h) if clip.w / clip.h < w / h else clip.resize(width=w)

    zoom_amount = 0.06  # video boyunca %6 yakınlaşma — abartısız, göz yormaz

    def zoom(t):
        return 1 + zoom_amount * (t / duration)

    clip = clip.resize(zoom).set_position(("center", "center")).set_duration(duration)

    # Ortadan hedef çözünürlüğe kırp
    clip = CompositeVideoClip([clip], size=resolution).set_duration(duration)
    return clip


def _section_durations(script: dict, total_duration: float) -> list[float]:
    """Her bölümün ses süresini, kelime sayısı oranına göre tahmin eder."""
    sections = script["long_form_sections"]
    word_counts = [max(len(s["narration"].split()), 1) for s in sections]
    total_words = sum(word_counts)
    return [total_duration * (wc / total_words) for wc in word_counts]


def build_base_video(
    image_paths: list[str],
    durations: list[float],
    resolution: tuple[int, int],
    audio_path: str,
    out_path: Path,
) -> Path:
    """Görsel + ses -> alt yazısız ham video (mp4)."""
    clips = [
        _ken_burns_clip(img, dur, resolution) for img, dur in zip(image_paths, durations)
    ]
    video = concatenate_videoclips(clips, method="compose")

    audio = AudioFileClip(audio_path)
    video = video.set_audio(audio).set_duration(audio.duration)

    video.write_videofile(
        str(out_path),
        fps=settings.FPS,
        codec="libx264",
        audio_codec="aac",
        threads=4,
        preset="medium",
        logger=None,
    )
    video.close()
    audio.close()
    return out_path


def burn_subtitles(
    raw_video_path: str,
    srt_path: str,
    out_path: Path,
    font_size: int = 44,
    orientation: str = "landscape",
) -> Path:
    """ffmpeg subtitles filtresiyle alt yazıyı videoya kalıcı olarak yakar."""
    if orientation == "portrait":
        font_size = 60  # dikey/mobil videoda daha büyük ve okunaklı olsun

    # ffmpeg'de Windows path ayrıştırma sorunlarından kaçınmak için
    # subtitle path'i olduğu gibi tırnak içinde veriyoruz (Linux ortamında çalışır).
    style = (
        f"FontName=DejaVu Sans,FontSize={font_size},PrimaryColour=&H00FFFFFF,"
        "OutlineColour=&H00000000,BorderStyle=3,Outline=2,Shadow=0,"
        "Alignment=2,MarginV=60"
    )
    vf = f"subtitles='{srt_path}':force_style='{style}'"

    cmd = [
        FFMPEG_EXE,
        "-y",
        "-i",
        raw_video_path,
        "-vf",
        vf,
        "-c:a",
        "copy",
        str(out_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg alt yazı yakma hatası:\n{result.stderr[-2000:]}")
    return out_path


def build_long_form_video(
    script: dict, image_paths: list[str], audio_path: str, srt_path: str, out_name: str
) -> str:
    resolution = settings.LONGFORM_RESOLUTION
    audio = AudioFileClip(audio_path)
    total_duration = audio.duration
    audio.close()

    durations = _section_durations(script, total_duration)

    raw_path = settings.VIDEOS_DIR / f"{out_name}_raw.mp4"
    final_path = settings.VIDEOS_DIR / f"{out_name}_longform.mp4"

    build_base_video(image_paths, durations, resolution, audio_path, raw_path)
    burn_subtitles(str(raw_path), srt_path, final_path, orientation="landscape")
    raw_path.unlink(missing_ok=True)

    print(f"[video_builder] Uzun video hazır: {final_path}")
    return str(final_path)


def build_shorts_video(
    image_path: str, audio_path: str, srt_path: str, out_name: str
) -> str:
    resolution = settings.SHORTS_RESOLUTION
    audio = AudioFileClip(audio_path)
    duration = audio.duration
    audio.close()

    raw_path = settings.VIDEOS_DIR / f"{out_name}_shorts_raw.mp4"
    final_path = settings.VIDEOS_DIR / f"{out_name}_shorts.mp4"

    build_base_video([image_path], [duration], resolution, audio_path, raw_path)
    burn_subtitles(str(raw_path), srt_path, final_path, orientation="portrait")
    raw_path.unlink(missing_ok=True)

    print(f"[video_builder] Shorts/Reels videosu hazır: {final_path}")
    return str(final_path)
