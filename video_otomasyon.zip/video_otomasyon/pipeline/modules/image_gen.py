"""
Görsel üretim modülü — varsayılan olarak Pollinations.ai kullanır
(https://pollinations.ai) — tamamen ücretsiz, API key gerektirmeyen bir
görsel üretim servisi. İleride başka bir sağlayıcıya (Stable Diffusion,
Stability API, vb.) geçmek istersen sadece bu dosyayı değiştirmen yeterli;
pipeline'ın geri kalanı etkilenmez.
"""
import hashlib
import sys
import time
from pathlib import Path
from urllib.parse import quote

import requests

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
from config import settings

POLLINATIONS_BASE = "https://image.pollinations.ai/prompt/"


def _pollinations_generate(prompt: str, width: int, height: int, seed: int) -> bytes:
    url = (
        f"{POLLINATIONS_BASE}{quote(prompt)}"
        f"?width={width}&height={height}&seed={seed}&nologo=true"
    )
    resp = requests.get(url, timeout=120)
    resp.raise_for_status()
    return resp.content


def generate_image(
    prompt: str,
    out_name: str,
    orientation: str = "landscape",
    retries: int = 3,
) -> str:
    """
    prompt -> output/images/<out_name>.jpg

    orientation: "landscape" (uzun video, 16:9) ya da "portrait" (shorts, 9:16)
    """
    if orientation == "portrait":
        width, height = 1080, 1920
    else:
        width, height = 1920, 1080

    # Aynı prompt her seferinde farklı görsel versin diye zamana bağlı seed
    seed = int(hashlib.sha256(f"{prompt}{time.time()}".encode()).hexdigest(), 16) % 1_000_000

    out_path = settings.IMAGES_DIR / f"{out_name}.jpg"

    last_error = None
    for attempt in range(1, retries + 1):
        try:
            if settings.IMAGE_PROVIDER == "pollinations":
                data = _pollinations_generate(prompt, width, height, seed)
            else:
                raise ValueError(
                    f"Bilinmeyen IMAGE_PROVIDER: {settings.IMAGE_PROVIDER}"
                )
            out_path.write_bytes(data)
            print(f"[image_gen] Görsel oluşturuldu: {out_path}")
            return str(out_path)
        except Exception as e:  # noqa: BLE001
            last_error = e
            print(f"[image_gen] Deneme {attempt}/{retries} başarısız: {e}")
            time.sleep(2 * attempt)

    raise RuntimeError(f"Görsel üretilemedi ({out_name}): {last_error}")


def generate_images_for_script(script: dict, orientation: str = "landscape") -> list[str]:
    """
    script_generator'dan gelen "long_form_sections" listesindeki her bölüm
    için bir görsel üretir. Dönüş: görsel dosya yollarının listesi (sıralı).
    """
    paths = []
    for i, section in enumerate(script["long_form_sections"]):
        prompt = section["visual_prompt"]
        out_name = f"section_{i+1:02d}_{orientation}"
        paths.append(generate_image(prompt, out_name, orientation=orientation))
    return paths


if __name__ == "__main__":
    generate_image(
        "realistic photo of fresh vegetables and fruits on a wooden table, healthy diet",
        "test_image",
    )
