"""
Senaryo üretim modülü.

Google Gemini API (ücretsiz kota) kullanarak; verilen niş ve konudan
- 10-12 dakikalık YouTube uzun video senaryosu
- Aynı konudan kısa/Shorts-Reels senaryosu (45-60 sn)
- Başlık, açıklama, etiket/hashtag önerileri
- Her bölüm için görsel üretim prompt'u (image_gen modülü bunu kullanacak)
üretir ve output/scripts/ altına JSON olarak kaydeder.

Gemini API key'i olmayan biri için de çalışsın diye, key boşsa
örnek/mock bir senaryo üretilir (pipeline'ın geri kalanını key
almadan test edebilmek için).
"""
import json
import re
import sys
from datetime import datetime
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
from config import settings

SYSTEM_INSTRUCTION = """Sen deneyimli bir YouTube senaristisin. Spor, sağlık ve beslenme \
konusunda, izleyiciyi başından sonuna kadar sürükleyen, bilimsel açıdan yanlış \
bilgi vermeyen, abartılı sağlık iddiaları içermeyen (YouTube reklam politikasına \
uygun) senaryolar yazıyorsun.

Kurallar:
- Doğal, konuşma diline yakın Türkçe kullan. Yapay/robotik cümlelerden kaçın.
- Kesin tıbbi teşhis/tedavi iddiası verme; "uzmanlar öneriyor", "araştırmalar gösteriyor" gibi \
temkinli ifadeler kullan.
- İlk 10-15 saniye (hook) izleyiciyi mutlaka konuya kilitlemeli.
- Video ilerledikçe merak unsurunu canlı tut, düz liste okur gibi yazma.
- Video sonunda doğal bir abone/beğeni/yorum çağrısı (CTA) olsun.
- Her bölüm için ayrıca o bölümde ekranda görünecek görseli tarif eden, \
İngilizce, resim üretim modeline uygun kısa bir 'visual_prompt' yaz \
(gerçekçi, telifsiz stok görsel tarzında; ünlü/marka ismi geçirme).
"""

USER_PROMPT_TEMPLATE = """Konu/niş: {niche}
Alt konu: {topic}

Aşağıdaki tam JSON şemasına birebir uyan, SADECE JSON döndür (başka hiçbir açıklama yazma):

{{
  "title": "YouTube video başlığı (tıklanabilir, tıklama tuzağı değil, max 90 karakter)",
  "description": "YouTube açıklama kutusu için 2-3 paragraf, SEO'ya uygun metin",
  "tags": ["etiket1", "etiket2", "... 10-15 adet"],
  "hashtags": ["#etiket1", "#etiket2", "... 5-8 adet"],
  "hook": "İlk 10-15 saniyede söylenecek dikkat çekici açılış cümlesi(leri)",
  "long_form_sections": [
    {{
      "heading": "Bölüm başlığı (kısa)",
      "narration": "Bu bölümde seslendirmede okunacak tam metin (doğal konuşma dili)",
      "visual_prompt": "English prompt describing the visual for this section"
    }}
  ],
  "outro_cta": "Videonun sonunda söylenecek abone/beğeni/yorum çağrısı metni",
  "shorts_script": {{
    "hook": "Shorts için ilk 3 saniyelik çarpıcı açılış",
    "narration": "45-60 saniyede okunacak tam Shorts/Reels metni (tek parça)",
    "visual_prompt": "English prompt describing the single background visual for the short",
    "caption": "Instagram/TikTok paylaşım metni + hashtag'ler"
  }}
}}

Önemli: "long_form_sections" toplamda yaklaşık {target_words} kelime olacak şekilde \
(hook ve outro hariç, sadece narration alanları toplamı), 6-9 bölüm halinde, \
akıcı ve meraklandırıcı bir sırayla yazılsın. Kelime hedefine ({target_words} kelime, \
±150 tolerans) mutlaka uy."""


def _target_words():
    return settings.LONGFORM_TARGET_MINUTES * settings.WORDS_PER_MINUTE


def _mock_script(niche: str, topic: str) -> dict:
    """GEMINI_API_KEY yokken pipeline'ı test edebilmek için örnek senaryo."""
    return {
        "title": f"{topic} Hakkında Bilmeniz Gereken Her Şey",
        "description": f"{niche} konusunda {topic} üzerine kapsamlı bir video. "
        f"(Bu bir ÖRNEK/MOCK senaryodur — GEMINI_API_KEY tanımlanmadığı için "
        f"gerçek üretim yapılmadı.)",
        "tags": [niche, topic, "sağlık", "spor", "beslenme"],
        "hashtags": ["#saglik", "#spor", "#beslenme"],
        "hook": f"{topic} hakkında bildiğinizi sandığınız her şey yanlış olabilir...",
        "long_form_sections": [
            {
                "heading": f"Bölüm {i+1}",
                "narration": (
                    f"Bu, {topic} ile ilgili {i+1}. bölümün örnek metnidir. "
                    "Gerçek üretim için GEMINI_API_KEY ayarlayın. " * 8
                ),
                "visual_prompt": f"realistic stock photo related to {topic}, section {i+1}",
            }
            for i in range(7)
        ],
        "outro_cta": "Videoyu beğendiyseniz abone olmayı ve yorum yazmayı unutmayın!",
        "shorts_script": {
            "hook": f"{topic} hakkında 3 şaşırtıcı gerçek!",
            "narration": f"Bu, {topic} hakkında örnek bir Shorts metnidir. " * 6,
            "visual_prompt": f"vertical realistic photo related to {topic}",
            "caption": f"{topic} hakkında bilmeniz gerekenler #saglik #spor #beslenme",
        },
        "_mock": True,
    }


def _extract_json(text: str) -> dict:
    """Gemini bazen ```json ... ``` bloğu içinde döner; temizleyip parse eder."""
    text = text.strip()
    match = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.DOTALL)
    if match:
        text = match.group(1)
    else:
        # İlk { ile son } arasını al (baştaki/sondaki gürültüyü temizle)
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1:
            text = text[start : end + 1]
    return json.loads(text)


def generate_script(topic: str, niche: str = None) -> dict:
    """
    Verilen konu için senaryo üretir ve output/scripts/ içine kaydeder.
    Döndürülen dict, main.py ve diğer modüller tarafından kullanılır.
    """
    niche = niche or settings.DEFAULT_NICHE
    target_words = _target_words()

    if not settings.GEMINI_API_KEY:
        print(
            "[script_generator] UYARI: GEMINI_API_KEY tanımlı değil (.env dosyasına ekleyin). "
            "Örnek/mock senaryo üretiliyor."
        )
        data = _mock_script(niche, topic)
    else:
        import google.generativeai as genai

        genai.configure(api_key=settings.GEMINI_API_KEY)
        model = genai.GenerativeModel(
            model_name="gemini-2.0-flash",
            system_instruction=SYSTEM_INSTRUCTION,
        )
        prompt = USER_PROMPT_TEMPLATE.format(
            niche=niche, topic=topic, target_words=target_words
        )
        response = model.generate_content(
            prompt,
            generation_config={"temperature": 0.9, "response_mime_type": "application/json"},
        )
        data = _extract_json(response.text)

    # Kaydet
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_topic = re.sub(r"[^a-zA-Z0-9_-]+", "_", topic)[:40]
    out_path = settings.SCRIPTS_DIR / f"{timestamp}_{safe_topic}.json"
    out_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    data["_saved_path"] = str(out_path)

    word_count = sum(len(s["narration"].split()) for s in data["long_form_sections"])
    print(
        f"[script_generator] Senaryo kaydedildi: {out_path} "
        f"(uzun video ~{word_count} kelime, hedef {target_words})"
    )
    return data


if __name__ == "__main__":
    topic = sys.argv[1] if len(sys.argv) > 1 else "Bağırsak sağlığı ve sindirim"
    generate_script(topic)
