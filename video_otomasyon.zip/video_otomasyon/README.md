# Video Otomasyon Pipeline (Spor / Sağlık / Beslenme)

Bir konu başlığı verdiğinde otomatik olarak:
- Senaryo (uzun video + Shorts/Reels) yazan,
- Türkçe seslendirme yapan,
- Görsel üreten,
- Alt yazı ekleyen,
- 16:9 uzun video ve 9:16 Shorts/Reels videosu render eden,
- onayından sonra YouTube'a yükleyen

bir Python pipeline'ı.

## Kullanılan araçlar (hepsi ücretsiz / ücretsiz kotalı)

| Adım | Araç | Neden |
|---|---|---|
| Senaryo | Google Gemini API | Cömert ücretsiz kota, Türkçe kalitesi iyi |
| Seslendirme | edge-tts | Tamamen ücretsiz, key gerekmez, doğal Türkçe sesler |
| Görsel | Pollinations.ai | Tamamen ücretsiz, key gerekmez |
| Alt yazı | edge-tts kelime zamanlamaları + ffmpeg | Ayrı bir transkripsiyon adımına gerek yok, %100 doğru |
| Video birleştirme | moviepy + ffmpeg | Açık kaynak, yerel çalışır |
| Yayınlama | YouTube Data API v3 | Resmi, ücretsiz kota yeterli |

Instagram/TikTok/Facebook için resmi API'ler kısıtlı/onay gerektirdiğinden,
ilk aşamada pipeline bu platformlar için hazır video + paylaşım metni +
kontrol listesi üretiyor; sen elle yüklüyorsun. İstersen ilerleyen aşamada
bunları da otomatikleştirebiliriz.

## Kurulum

### 1) Sistem gereksinimleri
```bash
# ffmpeg kurulu olmalı (moviepy render için kullanır)
# Ubuntu/Debian:
sudo apt-get install -y ffmpeg
# macOS:
brew install ffmpeg
```

### 2) Python ortamı
```bash
cd video_otomasyon
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3) Gemini API key al (ücretsiz)
1. https://aistudio.google.com/apikey adresine git, Google hesabınla giriş yap.
2. "Create API key" ile bir anahtar oluştur.
3. Proje kök dizininde `.env.example` dosyasını `.env` olarak kopyala:
   ```bash
   cp .env.example .env
   ```
4. `.env` dosyasını aç, `GEMINI_API_KEY=` satırına anahtarını yapıştır.

### 4) (Opsiyonel, ileride) YouTube otomatik yükleme kurulumu
`pipeline/modules/publisher_youtube.py` dosyasının en üstündeki adımları izle
(Google Cloud Console'da proje aç, YouTube Data API v3'ü etkinleştir, OAuth
client indir). Bunu yapmadan da pipeline çalışır — sadece YouTube'a otomatik
yükleme adımını atlar, sana video dosyalarının yolunu verir.

## Çalıştırma

```bash
python main.py "Bağırsak sağlığı ve sindirim"
```

Ne olacak:
1. Terminalde ilerleme adımlarını göreceksin (senaryo → ses → görsel → video).
2. Video hazır olunca terminal duracak ve videoları izlemen için dosya
   yollarını gösterecek (`output/videos/` klasörü).
3. Videoları izleyip onaylarsan terminale `evet` yazarsın, YouTube'a
   (gizli/private olarak) yüklenir. Onaylamazsan pipeline durur, dosyalar
   klasörde kalır, istediğin gibi elle düzenleyip paylaşabilirsin.

Farklı bir niş denemek için:
```bash
python main.py "Kas gelişimi için protein alımı" --niche "spor ve fitness"
```

## Klasör yapısı

```
video_otomasyon/
├── main.py                     # Ana pipeline (buradan çalıştırılır)
├── config/
│   ├── settings.py             # Tüm ayarlar (.env'den okur)
│   └── youtube_client_secret.json   # (sen ekleyeceksin, opsiyonel)
├── pipeline/modules/
│   ├── script_generator.py     # Gemini ile senaryo üretimi
│   ├── tts.py                  # edge-tts seslendirme + kelime zamanlaması
│   ├── subtitles.py            # Zamanlamalardan SRT üretimi
│   ├── image_gen.py            # Pollinations.ai görsel üretimi
│   ├── video_builder.py        # moviepy + ffmpeg ile video render
│   └── publisher_youtube.py    # YouTube'a yükleme
└── output/
    ├── scripts/                # Üretilen senaryolar (JSON)
    ├── audio/                  # Seslendirme dosyaları + kelime zamanlamaları
    ├── images/                 # Üretilen görseller
    ├── subtitles/              # SRT dosyaları
    └── videos/                 # Final videolar (buradan izlersin)
```

## API key olmadan test etme

`GEMINI_API_KEY` boşsa, `script_generator` gerçek üretim yerine kısa bir
**örnek/mock senaryo** üretir. Bu sayede Gemini hesabı açmadan önce ffmpeg
kurulumunun, seslendirmenin, alt yazının ve video render'ının doğru
çalıştığını test edebilirsin:

```bash
python main.py "test konusu"
```

## Sırada ne var / genişletme fikirleri

- Instagram/TikTok/Facebook otomatik yükleme (Meta Graph API, TikTok Content
  Posting API) — onay süreçleri var, istersen birlikte kuralım.
- Arka plan müziği ekleme (`assets/music/` klasörüne dosya koyup
  video_builder'a karıştırma adımı eklenebilir).
- Görsel yerine gerçek stok video klipleri kullanma (Pexels/Pixabay ücretsiz
  API'leri).
- Toplu üretim: bir CSV/liste konu okuyup gece boyu birden fazla video
  hazırlayan bir mod.
- Zamanlanmış otomatik çalıştırma (örn. her gün belirli saatte).

Bu dosyaların hepsi düzenlenebilir başlangıç noktası — birlikte adım adım
geliştirmeye devam edebiliriz.
