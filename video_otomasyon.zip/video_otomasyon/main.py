#!/usr/bin/env python3
"""
Ana pipeline — tüm modülleri sırayla çalıştırır:

  1) Senaryo üret (script_generator)
  2) Uzun video seslendirmesi + kelime zamanlamaları (tts)
  3) Uzun video alt yazısı (subtitles)
  4) Bölüm görselleri (image_gen)
  5) Uzun video render (video_builder)
  6) Shorts/Reels seslendirme + alt yazı + görsel + render
  7) *** ONAY ADIMI *** — üretilen videoları izlemen için burada durur
  8) Onaylarsan YouTube'a yükler, diğer platformlar için kontrol listesi basar

Kullanım:
    python main.py "Bağırsak sağlığı ve sindirim"
    python main.py "Kas gelişimi için protein" --niche "spor ve fitness"
    python main.py "Aralıklı oruç" --auto-publish   # onay adımını atla (dikkatli kullan!)
"""
import argparse
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from config import settings
from pipeline.modules import (
    image_gen,
    publisher_youtube,
    script_generator,
    subtitles,
    tts,
    video_builder,
)


def run_pipeline(topic: str, niche: str = None, auto_publish: bool = False):
    print(f"\n>>> KONU: {topic}\n")

    # 1) Senaryo
    script = script_generator.generate_script(topic, niche=niche)
    slug = topic.lower().replace(" ", "_")[:30]

    # 2-3) Uzun video seslendirme + alt yazı
    long_text = " ".join(s["narration"] for s in script["long_form_sections"])
    long_text = script["hook"] + " " + long_text + " " + script["outro_cta"]
    tts_result = tts.synthesize(long_text, out_name=f"{slug}_long")
    srt_path = subtitles.generate_subtitles(tts_result["words_path"], out_name=f"{slug}_long")

    # 4) Görseller
    image_paths = image_gen.generate_images_for_script(script, orientation="landscape")

    # 5) Uzun video render
    long_video_path = video_builder.build_long_form_video(
        script, image_paths, tts_result["audio_path"], srt_path, out_name=slug
    )

    # 6) Shorts/Reels
    shorts_text = script["shorts_script"]["hook"] + " " + script["shorts_script"]["narration"]
    shorts_tts = tts.synthesize(shorts_text, out_name=f"{slug}_shorts")
    shorts_srt = subtitles.generate_subtitles(
        shorts_tts["words_path"], out_name=f"{slug}_shorts"
    )
    shorts_image = image_gen.generate_image(
        script["shorts_script"]["visual_prompt"], f"{slug}_shorts_img", orientation="portrait"
    )
    shorts_video_path = video_builder.build_shorts_video(
        shorts_image, shorts_tts["audio_path"], shorts_srt, out_name=slug
    )

    video_paths = {"Uzun video (16:9)": long_video_path, "Shorts/Reels (9:16)": shorts_video_path}

    print("\n" + "=" * 60)
    print("ÜRETİM TAMAMLANDI — ONAY BEKLENİYOR")
    print("=" * 60)
    print(f"Başlık: {script['title']}")
    for label, path in video_paths.items():
        print(f"{label}: {path}")
    print("=" * 60)

    if script.get("_mock"):
        print(
            "\nUYARI: Bu bir MOCK senaryodur (GEMINI_API_KEY ayarlı değildi). "
            "Gerçek içerik için .env dosyasına API key ekleyip tekrar çalıştırın.\n"
        )

    # 7) ONAY ADIMI
    if not auto_publish:
        answer = input(
            "\nVideoları izleyip kontrol ettin mi? YouTube'a yüklemek için 'evet' yaz, "
            "iptal etmek için başka bir tuşa bas: "
        ).strip().lower()
        if answer not in ("evet", "e", "yes", "y"):
            print("Yayınlama iptal edildi. Videolar output/videos/ klasöründe duruyor.")
            return

    # 8) Yayınlama
    try:
        publisher_youtube.upload_video(
            long_video_path,
            title=script["title"],
            description=script["description"],
            tags=script.get("tags", []),
            privacy_status="private",  # ilk testlerde "private" - kontrol edip sen "public" yap
            is_shorts=False,
        )
        publisher_youtube.upload_video(
            shorts_video_path,
            title=script["shorts_script"]["hook"][:95],
            description=script["shorts_script"]["caption"],
            tags=script.get("tags", []),
            privacy_status="private",
            is_shorts=True,
        )
    except FileNotFoundError as e:
        print(f"\n[UYARI] YouTube otomatik yükleme henüz kurulmamış: {e}")
        print("Kurulum için pipeline/modules/publisher_youtube.py dosyasının başındaki adımları izleyin.")

    publisher_youtube.print_manual_upload_checklist(script, video_paths)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Otomatik video üretim pipeline'ı")
    parser.add_argument("topic", help="Video konusu, örn: 'Bağırsak sağlığı ve sindirim'")
    parser.add_argument("--niche", default=None, help="Niş override (varsayılan: spor/sağlık/beslenme)")
    parser.add_argument(
        "--auto-publish", action="store_true", help="Onay adımını atla, direkt yayınla (dikkatli kullan)"
    )
    args = parser.parse_args()
    run_pipeline(args.topic, niche=args.niche, auto_publish=args.auto_publish)
